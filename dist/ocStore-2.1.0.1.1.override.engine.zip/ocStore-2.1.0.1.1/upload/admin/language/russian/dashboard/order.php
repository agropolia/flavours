<?php
// Heading
$_['heading_title'] = 'Всего заказов';

// Text
$_['text_view']     = 'Подробнее...';