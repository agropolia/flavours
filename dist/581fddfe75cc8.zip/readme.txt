Override Engine (v6.5.3) for OpenCart 2.1.0.1
=============================================

This package provides a replacement system engine for OpenCart.
It uses the same MVC architecture as the standard OpenCart framework.

All instances of controller, model, or library classes are created
by a special factory class.

Am additional override feature is supported. This allows 3rd party addons
to do changes to the OpenCart core classes, templates, and language
files. Core controller, model and library classes can be extended and their
methods be overridden in a normal object oriented programming manner.


Installation
============

Before proceeding with the installation: Log into the admin backend,  proceed to Extensions > Modifications, 
and click on the Clear button located near the top right corner.

Now simply upload the folders and files from the 'upload' directory via FTP to your OpenCart server's main directory.

The following OpenCart files are replaced by the upload:

  admin/index.php
  index.php
  system/engine/action.php
  system/engine/controller.php
  system/engine/loader.php
  system/library/language.php
  system/startup.php



Frequently Asked Questions
==========================

Q:  Where do overrides go?
A:  All overrides go into a new directory named 'override'.

  It uses the following directory structure, only files
  which are to be modified in the OpenCart core are needed.

  - override
    - <addon-1>
      - admin
        - controller
          + ...
        - language
          + ...
        - model
          + ...
      - catalog
        - controller
          + ...
        - language
          + ...
        - model
          + ...
      - system
        - library
          + ...
    + <addon-2>
      ...
    + <addon-n>




Q:  Can I have an example please?
A:  Sure, why not:

  For example, if 'addon-x' needs a new field named 'myfield' on the frontend product page,
  it typically needs to modify the following core class files:

    catalog/controller/product/product.php
    catalog/language/english/product/product.php
    catalog/model/catalog/product.php

  We therefore define the following override files (extended classes):

    override/addon-x/catalog/controller/product/product.php
    override/addon-x/catalog/language/english/product/product.php
    override/addon-x/catalog/model/catalog/product.php

  Assuming the database has a new field name 'myfield' in the 'product' table, 
  then the extended controller may look something like this:

	<?php
	class addon_x_ControllerProductProduct extends ControllerProductProduct {

		/* overridden method, this newly introduced function is always called
		before the final rendering
		*/
		public function preRender( $template_buffer, $template_name, &$data ) {
			if ($template_name != $this->config->get( 'config_template' ).'/template/product/product.tpl') {
				return parent::preRender( $template_buffer, $template_name, $data );
			}
		
			// add new controller variables
			if (isset($this->request->get['product_id'])) {
				$product_id = $this->request->get['product_id'];
			$this->load->model( 'catalog/product' );
				$product = $this->model_catalog_product->getProduct($product_id');
				$data['myfield'] = $product['myfield'];
				$this->load->language( 'product/product' );
				$data['text_myfield'] = $this->language->get( 'text_myfield' );
			} else {
				$this->data['myfield'] = '';
				$this->data['text_myfield'] = '';
			}

			// modify template file
			$template_buffer = str_replace(
				'<?php echo $description; ?>',
				'<?php echo $description; ?><br /><?php echo $text_myfield; ?>:<?php echo $myfield; ?>',
				$template_buffer
			);

			// call parent method
			return parent::preRender( $template_buffer, $template_name, $data );
		}
	}
	?>

  The model extension looks something like this:

	<?php
	class addon_x_ModelCatalogProduct extends ModelCatalogProduct {
	
		/* override method */
		public function getProduct($product_id) {
			$product = parent::getProduct( $product_id );
			if ($product) {
				$sql  = "SELECT myfield FROM `".DB_PREFIX.product` ";
				$sql .= "WHERE product_id='".(int)$product_id."'";
				$result = $this->db->query($sql);
				$product['myfield'] = $result->row['myfield'];
			} else {
				$product['myfield'] = '';
			}
			return $product;
		}
	}
	?>

  The language override might look like this:

	<?php
	// new texts
	$_['text_myfield'] = 'This is the new field:';
	?>



Q:  Can I modify core templates?
A:  You sure can! 

  However, in most cases you'd want to use your own web theme rather than OpenCart's 'default' theme. 
  And if you use your own web theme, you can simply add any new fields directly 
  into the template file of your new theme. This way, only the corresponding controller class 
  needs to be extended with overridden methods which can populate your new variables for your template.

  In case you think you have to modify a core OpenCart
  template file, you can extend the controller class and override
  a method called 'preRender', as in the previous example.

  Method preRender is a newly added hook which is always called just before rendering a template.
  Always be nice and call the parent method, too!



Q:  Can multiple addons modify the same core file?
A:  Absolutely! 

  As part of the new OpenCart core engine, a special factory
  class is used for loading (possibly extended) classes.
  The nature of external addons is that they are not aware of each
  other. Each addon may extend and override the same OpenCart core
  class and method. However, if 2 or more addons do this, the new
  OpenCart factory loads the original core class and all extended
  classes and then modifies the parent class of each addon's
  extended class, so they all end up in a chain of class extensions.

  For example, if addon_1, addon_2 and addon_3 all extend the
  same core class ControllerProductProduct, their original class definitions

    class addon_1_ControllerProductProduct extends ControllerProductProduct {
      ....
    }

    class addon_2_ControllerProductProduct extends ControllerProductProduct {
      ....
    }

    class addon_3_ControllerProductProduct extends ControllerProductProduct {
      ....
    }

  are modified like this before to become a chain of class extensions, before loading them:

    class addon_1_ControllerProductProduct extends ControllerProductProduct {
      ....
    }

    class addon_2_ControllerProductProduct extends addon_1_ControllerProductProduct {
      ....
    }

    class addon_3_ControllerProductProduct extends addon_2_ControllerProductProduct {
      ....
    }

  All classes modified this way are loaded, and then a new instance of 
  'addon_3_ControllerProductProduct' is created. 

  Every overridden method in an extended class always has to call the parent method,
  otherwise the chain gets broken! But other than that, there are no restrictions.



Q:  Are OCmod, VQmod or Event handlers supported?
A:  Yes, they are. 

  The Override Engine can co-exist with
  OpenCart's XML-based dynamic source code modifications
  like OCmod or VQmod.

  And the Override Engine can even be used to modify Event handlers,
  in addition to controller classes, model classes and some library classes.



Q:  Why does the Controller class have the new method named preRender?
A:  This is actually a newly introduced hook function.

  Any controller class can be extended and method preRender can
  then be overridden. Method preRender is called just before the
  selected template is rendered. You can do 3 things in here:

  1) Add new controller variables to the $this->data array
     as needed by the modified template.
  2) Modify the template buffer.
  3) Do any other changes before rendering the template.
    


Change Log
==========

Version 1.0 - 4 October 2012:
 - Original release

Version 2.0 - 17 October 2012:
 - Bugfixes for VQmod support

Version 3.0 - 3 November 2012:
 - Bugfixes in Factory class for loading library classes
 - Added method stream_cast to class VariableStream

Version 3.2 - 16 November 2012:
- bugfix in system/engine/controller.php
  (function render)
- bugfix in system/helper/modifier.php

Version 3.3 - 21 November 2012:
- bugfix in system/engine/controller.php
  in function getChild for VQmod support

Version 3.4 - 26 November 2012:
- bugfix in system/helper/modifier.php

Version 3.5 - 27 November 2012:
- more bugfixes in system/helper/modifier.php

Version 4.0 - 2 December 2012
- added skipping comments when parsing a class file
  in system/engine/factory.php

Version 4.1 - 14 January 2013
- library classes Template and Mail can now
  be extended, too

Version 5.0 - 22 January 2013
- improved the way language files are loaded,
  including fallback to default English

Version 5.1 - 19 February 2013
- bugfix in system/helper/modifier.php

Version 5.2 - 22 February 2013
- bugfix: added missing newMail and newTemplate
  methods in Factory class

Version 5.3 - 1 April 2013
- bugfix: PHP class parser to use case-insensitive
  tokens when they are standard keywords
- check that if an addon uses an extended final class
  then no other addons can extend the same parent class 

Version 5.4 - 28 July 2013
- bugfix: system/library/variable_stream.php
  added method url_stat

Version 6.0 - 24 August 2013
- add support for vqmod 2.4.x or later

Version 6.1 - 28 August 2013
- bugfix: Opencart version number

Version 6.2 - 5 May 2014
- bugfix: system/engine/factory loadLanguage

Version 6.3 - 6 July 2014
- bugfix: system/engine/factory actionProperties

Version 6.4 - 8 August 2014
- use cached files instead of variable stream for modified classes

Version 6.5 - 14 April 2015
- bugfix: system/engine/factory loadLangauge

Version 6.5.2 - 25 March 2016
- bugfix: fixes for supporting for VQMod

Version 6.5.3 - 1 April 2016
- bugfix: fix google site verification demo override



Further help and customized versions
====================================

This software has been successfully tested for a standard 
OpenCart 2.1.0.1. Don't use other Opencart versions with this software.

If you need a customized version of this module,
let us know and we can create one for a charge.

You can contact us at http://www.mhccorp.com

