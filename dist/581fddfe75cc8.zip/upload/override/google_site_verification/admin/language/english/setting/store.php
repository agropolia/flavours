<?php
// Additional Entry
$_['entry_google_site_verification'] = 'Meta Tag for Google site verification';
?>