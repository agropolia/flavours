<?php
// Heading
$_['heading_title'] 	= 'Всего покупателей';

// Text
$_['text_view'] 		= 'Подробнее...';